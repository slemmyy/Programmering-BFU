function Bye(){
    console.log('')
    function Bye(user){
        console.log('Thank you, ' + user + '!')
        }

        Bye('Come again')

    }

    export { Bye }