function Greeting(){
    console.log('')
    function Greeting(user){
        console.log('Welcome to the joke factory, ' + user + '!')
        }
    function Greeting2(user2){
        console.log('Let me tell you something ' + user2 + ':')
        }

        Greeting('Jinxter')
        Greeting2('about programming') 
    }

    export { Greeting }