/* function betyder att man startar upp något som kan anropas senare
Jokes är det som är namnet på det som ska anropas och { är starten på det vi vill anropa */
function Jokes() {

    //gör att koden får mellanrum innan den skriver sin kod
    console.log('')

    /* let gör en låda, Jokes är namnet på lådan (variabeln), = är vad vi ska fylla med 
    [ att skriva med denna typen gör att vi kan ha flera saker i en lista] */
    let Jokes = [ 
        //Använda Å i fråga ändrade färgen till grön så skriver Fråga med A för att få den vit
        //göra {} gör att varje id, fråga och svar blir ett objekt
        { Nummer: 0, Fraga: "Why don't programmers like nature?", Svar: "It has too many bugs." },
        { Nummer: 1, Fraga: "Why did the CSS developer go to therapy?", Svar: "To get rid of his margins." },
        { Nummer: 2, Fraga: "How do you comfort a JavaScript developer?", Svar: "You console them." },
        { Nummer: 3, Fraga: "Why did the CSS developer leave the restaurant?", Svar: "Because it had no class." },
        { Nummer: 4, Fraga: "Why did the JavaScript developer go missing?", Svar: "Because he didn't know when to return." },
        { Nummer: 5, Fraga: "Why did the HTML tag go to the party?", Svar: "Because it wanted to break the line." },
        { Nummer: 6, Fraga: "Why do JavaScript developers wear glasses?", Svar: "Because they don't C#." },
        { Nummer: 7, Fraga: "Why don't programmers like to use inline styles?", Svar: "Because they want to be classy." },
        { Nummer: 8, Fraga: "Why did the CSS selector break up with the HTML element?", Svar: "It found someone more specific." },
        { Nummer: 9, Fraga: "Why did the CSS developer apply for a job?", Svar: "They wanted to get a position." }
    ];

    /* math.random tillsammans med jokes.length = ett slumpat tal mellan 0 och hur många skämt där är
    math.floor tillsammans med math.random = slumpat Heltal (math.floor gör heltalet)
    let randomindex är lådan (variabeln) vi sparar värdet i */
    let randomIndex = Math.floor(Math.random() * Jokes.length);
    let randomIndex2 = Math.floor(Math.random() * Jokes.length);

    /* While i denna delen betyder att så länge Index2 är likadana som Index 
    så ska den slumpa ett skämt igen */
    while (randomIndex2 === randomIndex) {
        randomIndex2 = Math.floor(Math.random() * Jokes.length);
    }

    //här är vad som skrivs ut i konsolen
    console.log(Jokes[randomIndex]);
    console.log('')
    console.log(Jokes[randomIndex2]);

} 
//export används för att kunna göra import i "huvud"filen så man kan dela upp koden mer
export { Jokes };
