import {Greeting} from "./Greeting.js"
import {Jokes} from "./Jokes.js";
import {Bye} from "./Bye.js"

Greeting()
Jokes()
Bye()